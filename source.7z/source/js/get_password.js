
document.documentElement.style.fontSize =
document.documentElement.clientWidth / 100 + "px";